package com.example.demo.service;


import com.example.demo.entity.*;

public interface CustomerService {


    public String processRegistrationForm(Bank bank,
                                          Branch branch,
                                          Customer customer,
                                          Account account,
                                          Loan loan);
}
