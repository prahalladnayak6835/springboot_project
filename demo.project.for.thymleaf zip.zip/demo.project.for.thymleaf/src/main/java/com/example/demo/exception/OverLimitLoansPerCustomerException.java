package com.example.demo.exception;

public class OverLimitLoansPerCustomerException
        extends RuntimeException{

    private String message;

    public OverLimitLoansPerCustomerException(){}

    public OverLimitLoansPerCustomerException(String msg){
        super(msg);
        this.message = msg;
    }
}
