package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.exception.NoSuchCustomerExistsException;
import com.example.demo.exception.OverLimitLoansPerBranchException;
import com.example.demo.exception.OverLimitLoansPerCustomerException;
import com.example.demo.repository.*;
import org.springframework.stereotype.Service;


@Service
public class CustomerServiceImpl implements CustomerService{
    private CustomerRepository customerRepository;
    private AccountRepository accountRepository;
    private LoanRepository loanRepository;
    private BranchRepository branchRepository;
    private BankRepository bankRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository,
                               AccountRepository accountRepository,
                               LoanRepository loanRepository,
                               BranchRepository branchRepository,
                               BankRepository bankRepository) {

        this.customerRepository = customerRepository;
        this.accountRepository = accountRepository;
        this.loanRepository = loanRepository;
        this.branchRepository = branchRepository;
        this.bankRepository=bankRepository;
    }


    @Override
    public String processRegistrationForm(Bank bank,
                                          Branch branch,
                                          Customer customer,
                                          Account account,
                                          Loan loan) {
        // Perform validation before saving the customer and branch
//        if (customer.getAccounts().isEmpty()) {
//            throw new NoSuchCustomerExistsException(
//                    "A customer must have at least one account."
//            );
//        }
//        if (customer.getLoans().size() > 2) {
//            throw new OverLimitLoansPerCustomerException(
//                    "A customer can have at most two loans at a time."
//            );
//        }
//        if (branch.getLoans().size() >= 1000) {
//            throw new OverLimitLoansPerBranchException(
//                    "A bank branch cannot have more than 1,000 loans."
//            );}
            bankRepository.save(bank);
            branch.setBank(bank);
            account.setBranch(branch);
            loan.setBranch(branch);
            branchRepository.save(branch);
            customerRepository.save(customer);
            account.setCustomer(customer);
            accountRepository.save(account);
            loan.setCustomer(customer);
            loanRepository.save(loan);

            return "details registered";
        }
    }
