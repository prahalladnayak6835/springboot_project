package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "loan")
public class Loan implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long loanId;

    private String loanType;

    private double amount;

    @ManyToOne
    @JoinColumn(
            name="customerId",
            foreignKey = @ForeignKey(
                    name = "fk_Customer_id_loan")
    )
    private Customer customer;

    @ManyToOne
    @JoinColumn(
            name="branchId",
            foreignKey = @ForeignKey(
                    name = "fk_Branch_id_loan")
    )
    private Branch branch;

    // Getter and Setter methods
}