package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "account")
public class Account implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long accountNumber;

    private String accountType;

    private double balance;

    @ManyToOne
    @JoinColumn(
            name="customerId",
            foreignKey = @ForeignKey(
                    name = "fk_Customer_id")
    )
    private Customer customer;

    @ManyToOne
    @JoinColumn(
            name="branchId",
            foreignKey = @ForeignKey(
                    name = "fk_Branch_id")
    )
    private Branch branch;

    // Getter and Setter methods
}