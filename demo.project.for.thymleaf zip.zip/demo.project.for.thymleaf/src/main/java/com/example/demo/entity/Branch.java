package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity

public class Branch implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long branchId;

    private String branchName;

    private String branchAddress;

    @ManyToOne
    @JoinColumn(
            name="bank_Code",
            foreignKey = @ForeignKey(
                    name = "fk_Bank_Code")
    )
    private Bank bank;

    @OneToMany( mappedBy = "branch")
    private List<Loan> loans;
    @OneToMany( mappedBy = "branch")
    private List<Account> accounts;

    // Getter and Setter methods
}
