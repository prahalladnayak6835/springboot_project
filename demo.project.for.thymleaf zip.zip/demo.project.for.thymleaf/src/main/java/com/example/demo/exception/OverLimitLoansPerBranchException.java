package com.example.demo.exception;

public class OverLimitLoansPerBranchException extends RuntimeException{
    private String message;

    public OverLimitLoansPerBranchException(){}

    public OverLimitLoansPerBranchException(String msg){
        super(msg);
        this.message = msg;
    }
}
