package com.example.demo.controller;

import com.example.demo.entity.*;
import com.example.demo.service.CustomerService;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@NoArgsConstructor
@Controller
public class HomeController {

    private CustomerService customerService;


@Autowired
    public HomeController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("bank", new Bank());
        model.addAttribute("branch", new Branch());
        model.addAttribute("customer", new Customer());
        model.addAttribute("account", new Account());
        model.addAttribute("loan", new Loan());
        return "registration-form";
    }
    @PostMapping("/register")
    public String processRegistrationForm(Bank bank,
                                          Branch branch,
                                          Customer customer,
                                          Account account,
                                          Loan loan) {

        customerService.processRegistrationForm(bank,branch,customer,account,loan);
        System.out.println("bank name"+ bank.getBank_Name());

        // Redirect to a success page
        return "redirect:/success";
    }
}
